Internal Notifications module for Dolibarr
=========

This module is use to send notifications when certain actions (Events, Contacts, Third parties)

This module is publish under licence GPL3 (see COPYING file)

Contact : gilles@artaban.fr
Website : artaban.fr

--------------------------------------


Ce module permet l'envoi de notifications lors de certaines actions ( Evènements, tiers et contacts )

Ce module est sous license GPL3 (voir le fichier COPYING)

Contact : gilles@artaban.fr
Site internet : artaban.fr
