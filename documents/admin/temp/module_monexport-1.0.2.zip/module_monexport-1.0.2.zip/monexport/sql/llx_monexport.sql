create table llx_monexport
(
  rowid           			int(11) AUTO_INCREMENT PRIMARY KEY,
  titre         			varchar(255)
 );
