-- <Extrafields table>
-- Copyright (C) <${current_year}>  <${author_name}>

ALTER TABLE llx_${table_name} ADD INDEX idx_${table_name} (fk_object);
