# Oblyon
Oblyon free theme for Dolibarr ERP & CRM

See installation and usage details in [htdocs/custom/oblyon/README.md](htdocs/custom/oblyon/README.md).
