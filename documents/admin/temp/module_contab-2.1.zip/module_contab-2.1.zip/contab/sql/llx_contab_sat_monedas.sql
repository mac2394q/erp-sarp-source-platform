CREATE TABLE IF NOT EXISTS `llx_contab_sat_monedas` (
  `rowid` int(11) NOT NULL AUTO_INCREMENT,
  `codigo` char(3) NOT NULL,
  `moneda` varchar(100) NOT NULL,
  PRIMARY KEY (`rowid`)
);