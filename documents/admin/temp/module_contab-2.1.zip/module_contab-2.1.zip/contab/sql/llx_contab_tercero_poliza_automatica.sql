CREATE TABLE `llx_contab_tercero_poliza_automatica` (
  `rowid` int(11) NOT NULL AUTO_INCREMENT,
  `pautomaticas` int(11) NOT NULL DEFAULT '0',
  `entity` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`rowid`)
);
