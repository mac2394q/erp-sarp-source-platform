ALTER TABLE `llx_contab_pol_recdet` ADD `descripcion` VARCHAR(80) AFTER `haber`;
ALTER TABLE `llx_contab_pol_recdet` ADD `uuid` VARCHAR(80) AFTER `descripcion`;
