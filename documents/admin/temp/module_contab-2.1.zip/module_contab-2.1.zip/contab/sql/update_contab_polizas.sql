ALTER TABLE `llx_contab_polizas` ADD `perajuste` int(11) NOT NULL DEFAULT '0' AFTER `societe_type`;
