CREATE TABLE IF NOT EXISTS `llx_contab_ctrl_almacen` (
  `rowid` int(11) NOT NULL AUTO_INCREMENT,
  `metodo_ctrl_almacen` tinyint(2) NOT NULL DEFAULT 1,
  PRIMARY KEY (`rowid`)
) ;