ALTER TABLE `llx_contab_polizasdet` ADD `descripcion` VARCHAR(80) AFTER `haber`;
ALTER TABLE `llx_contab_polizasdet` ADD `uuid` VARCHAR(80) AFTER `descripcion`;
