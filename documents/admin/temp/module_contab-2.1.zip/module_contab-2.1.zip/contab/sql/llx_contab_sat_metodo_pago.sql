CREATE TABLE IF NOT EXISTS `llx_contab_sat_metodo_pago` (
  `rowid` int(11) NOT NULL AUTO_INCREMENT,
  `clave` char(2) NOT NULL DEFAULT '',
  `concepto` varchar(30) NOT NULL DEFAULT '',
  PRIMARY KEY (`rowid`)
) ; 