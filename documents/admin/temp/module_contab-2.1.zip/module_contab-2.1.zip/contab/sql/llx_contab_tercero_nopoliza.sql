CREATE TABLE `llx_contab_tercero_nopoliza` (
  `rowid` int(11) NOT NULL AUTO_INCREMENT,
  `fk_societe` int(11) DEFAULT '0',
  PRIMARY KEY (`rowid`)
);
