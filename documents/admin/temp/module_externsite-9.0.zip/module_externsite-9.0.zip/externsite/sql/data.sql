/* commandes pour ajouter/manipuler les données de la table. */


