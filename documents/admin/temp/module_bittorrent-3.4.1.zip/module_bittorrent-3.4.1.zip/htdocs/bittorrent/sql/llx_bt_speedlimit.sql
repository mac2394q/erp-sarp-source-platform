
-- --------------------------------------------------------

-- 
-- 

CREATE TABLE llx_bt_speedlimit (
uploaded bigint(25) NOT NULL default 0,
total_uploaded bigint(30) NOT NULL default 0,
started bigint(25) NOT NULL default 0
) ENGINE = innodb;
